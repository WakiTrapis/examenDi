import { Routes } from '@angular/router';
import { CharacterListComponent } from './components/character-list-component/character-list-component';
import { CharacterModal } from './components/modal/character-modal/character-modal';

export const routes: Routes = [
    {path: 'character-list', component: CharacterListComponent},
    {path: '**', redirectTo: 'character-list'}
    
];
