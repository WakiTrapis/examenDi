import { Component, inject, Input } from '@angular/core';
import { CharacterDetailsResponse } from '../../../interfaces/character-details-response';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  imports: [],
  selector: 'app-character-modal',
  styleUrl: './character-modal.css',
  templateUrl: './character-modal.html',
})
export class CharacterModal {
  activeModal = inject(NgbActiveModal);              
  @Input() characterDetail: CharacterDetailsResponse | undefined;
}
