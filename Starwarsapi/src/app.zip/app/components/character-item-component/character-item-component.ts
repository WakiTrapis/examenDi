import { Component, input, output } from '@angular/core';
import { Item } from '../../interfaces/character-list-response';

@Component({
  imports: [],
  selector: 'app-character-item-component',
  styleUrl: './character-item-component.css',
  templateUrl: './character-item-component.html',
})
export class CharacterItemComponent {
  character= input<Item>();
  characterClicked= output<Item>();

  emitCharacterClicked() {
    this.characterClicked.emit(this.character()!);
  }
  
}
