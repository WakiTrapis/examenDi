import { Component, inject, OnInit, signal } from '@angular/core';
import { CharacterItemComponent } from '../character-item-component/character-item-component';
import { CharacterService } from '../../services/character-service';
import { Item } from '../../interfaces/character-list-response';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CharacterModal } from '../modal/character-modal/character-modal';

@Component({
  imports: [CharacterItemComponent],
  selector: 'app-character-list-component',
  styleUrl: './character-list-component.css',
  templateUrl: './character-list-component.html',
})
export class CharacterListComponent implements OnInit{
  characterService = inject(CharacterService);
  characterList = signal<Item[]>([]);
  private modalService = inject(NgbModal);

  ngOnInit(){
    this.characterService.getAll().subscribe((response) => {
      console.log(response);
      this.characterList.set(response.Items);
    });
  }

  openCharacterModal(item: Item) {
  this.characterService.getOne(item.id).subscribe(detail => {
    const modalRef = this.modalService.open(CharacterModal);
    modalRef.componentInstance.characterDetail = detail;
  });
}
  
}
