import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';
import { Observable } from 'rxjs';
import { CharacterListResponse } from '../interfaces/character-list-response';
import { CharacterDetailsResponse } from '../interfaces/character-details-response';

@Service()
export class CharacterService {

    http =inject(HttpClient);

    getAll(): Observable<CharacterListResponse> {
        return this.http.get<CharacterListResponse>('https://dragonball-api.com/api/characters/');
    }

    getOne(id: number): Observable<CharacterDetailsResponse> {
    return this.http.get<CharacterDetailsResponse>(`https://dragonball-api.com/api/characters/${id}`);
  }

    
}
