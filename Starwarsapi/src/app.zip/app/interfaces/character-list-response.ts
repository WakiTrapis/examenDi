export interface CharacterListResponse {
  Items: Item[]
  meta: Meta
  links: Links
}

export interface Item {
  id: number
  name: string
  image: string
  ki: string
}

export interface Meta {
  totalItems: number
  itemCount: number
  itemsPerPage: number
  totalPages: number
  currentPage: number
}

export interface Links {
  first: string
  previous: string
  next: string
  last: string
}